﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;

// Kinect SDK using
using Microsoft.Azure.Kinect.Sensor;
using Image = Microsoft.Azure.Kinect.Sensor.Image;
using OpenCvSharp;
using OpenCvSharp.Extensions;

namespace ImageTransformer_v1
{
    internal class Program
    {
        public static Image MakeImage(Bitmap depth_bitmap, string type)
        {
            int bitmap_width = depth_bitmap.Width;
            int bitmap_height = depth_bitmap.Height;
            int stride = bitmap_width * sizeof(UInt16);

            Image kinect_image = new Image(Microsoft.Azure.Kinect.Sensor.ImageFormat.Depth16, bitmap_width, bitmap_height, stride);
            for (int x = 0; x < bitmap_width; x++)
            {
                for (int y = 0; y < bitmap_height; y++)
                {
                    Color pixelColor = depth_bitmap.GetPixel(x, y);
                    Color newColor = Color.FromArgb(pixelColor.A, pixelColor.R, pixelColor.G, pixelColor.B);
                    UInt16 color = (UInt16)(newColor.ToArgb());
                    kinect_image.SetPixel(y, x, color);
                }
            }

            return kinect_image;
        }

        public static Bitmap GetImage(string depth_path)
        {
            Bitmap depth_bitmap = (Bitmap)System.Drawing.Image.FromFile(depth_path);

            return depth_bitmap;
        }

        public static Mat GetCVImage(string depth_path)
        {
            Bitmap btm = new Bitmap(depth_path);
            Mat img = Cv2.ImRead(depth_path, ImreadModes.Grayscale);

            return img;
        }

        public static Calibration SetCalibration(Calibration kinect_calibration)
        {
            Calibration tmp_calibration = kinect_calibration;

            float[] color_ext_rotation = new float[] { 0.9999643f, 0.008453462f, 2.81318E-05f, -0.008415033f, 0.9950903f, 0.09861279f, 0.0008056258f, -0.0986095f, 0.9951259f };
            float[] color_ext_translation = new float[] { -31.97428f, -1.906646f, 3.868288f };
            float[] color_ins = new float[] { 1026.882f, 777.1486f, 983.3638f, 983.558f, -0.1238888f, -2.440197f, 1.708939f, -0.2407829f, -2.222585f, 1.60195f, 0f, 0f, 0.0001137732f, 0.0007317961f, 0f };
            float[] depth_ins = new float[] { 316.4375f, 336.3702f, 504.1668f, 504.2513f, 0.6819282f, 0.2810397f, 0.01500589f, 1.020327f, 0.4497096f, 0.07871094f, 0, 0, 1.596063E-05f, -3.635334E-05f, 0 };

            tmp_calibration.ColorCameraCalibration.Extrinsics.Rotation = color_ext_rotation;
            tmp_calibration.ColorCameraCalibration.Extrinsics.Translation = color_ext_translation;
            tmp_calibration.ColorCameraCalibration.MetricRadius = 1.7f;
            tmp_calibration.ColorCameraCalibration.Intrinsics.Parameters = color_ins;

            tmp_calibration.DepthCameraCalibration.Extrinsics.Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            tmp_calibration.DepthCameraCalibration.Extrinsics.Translation = new float[] { 0, 0, 0 };
            tmp_calibration.DepthCameraCalibration.MetricRadius = 1.7f;
            tmp_calibration.DepthCameraCalibration.Intrinsics.Parameters = depth_ins;
            var device_ext = tmp_calibration.DeviceExtrinsics;


            device_ext[0].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[0].Translation = new float[] { 0, 0, 0 };

            device_ext[1].Rotation = new float[] { 0.9999643f, 0.008453462f, 2.81318E-05f, -0.008415033f, 0.9950903f, 0.09861279f, 0.0008056258f, -0.0986095f, 0.9951259f };
            device_ext[1].Translation = new float[] { -31.97428f, -1.906646f, 3.868288f };

            device_ext[2].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[2].Translation = new float[] { 0, 0, 0 };

            device_ext[3].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[3].Translation = new float[] { 0, 0, 0 };

            device_ext[4].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[4].Translation = new float[] { 0, 0, 0 };

            device_ext[5].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[5].Translation = new float[] { 0, 0, 0 };

            device_ext[6].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[6].Translation = new float[] { 0, 0, 0 };

            /*device_ext[7].Rotation = new float[] { 0.9999643f, -0.008415033f, 0.0008056258f, 0.008453462f, 0.9950903f, -0.0986095f, 2.81318E-05f, 0.09861279f, 0.9951259f };
            device_ext[7].Translation = new float[] { 31.95397f, 2.549028f, -3.660514f };*/

            /*            device_ext[7].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
                        device_ext[7].Translation = new float[] { 31.95397f, 2.549028f, -3.660514f };*/

            device_ext[8].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[8].Translation = new float[] { 0, 0, 0 };

            device_ext[9].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[9].Translation = new float[] { 0, 0, 0 };

            device_ext[10].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[10].Translation = new float[] { 0, 0, 0 };

            device_ext[11].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[11].Translation = new float[] { 0, 0, 0 };

            device_ext[12].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[12].Translation = new float[] { 0, 0, 0 };

            device_ext[13].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[13].Translation = new float[] { 0, 0, 0 };

            device_ext[14].Rotation = new float[] { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
            device_ext[14].Translation = new float[] { 0, 0, 0 };

            device_ext[15].Rotation = new float[] { 1, 0, 0, 0, 1, 0, 0, 0, 1 };
            device_ext[15].Translation = new float[] { 0, 0, 0 };

            return tmp_calibration;
        }

        public static WriteableBitmap DepthTransformer(Transformation tr, Image depth_image)
        {
            // Create Transformation Depth Image
            Image tr_img = tr.DepthImageToColorCamera(depth_image);
            byte[] tr_buff = tr_img.Memory.ToArray();
            Int32Rect rect = new Int32Rect(0, 0, tr_img.WidthPixels, tr_img.HeightPixels);

            WriteableBitmap wbitmap = new WriteableBitmap(tr_img.WidthPixels, tr_img.HeightPixels, 96.0, 96.0, System.Windows.Media.PixelFormats.Gray16, null);
            wbitmap.WritePixels(rect, tr_buff, tr_img.StrideBytes, 0, 0);
            wbitmap.Freeze();

            return wbitmap;
        }

        public static void ImageSave(WriteableBitmap wbitmap, string save_path)
        {
            try
            {
                if (save_path.Contains("png"))
                {
                    using (FileStream stream = new FileStream(save_path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        BitmapEncoder encoder = new PngBitmapEncoder();

                        encoder.Frames.Add(BitmapFrame.Create(wbitmap));
                        encoder.Save(stream);
                    }
                }

                if (save_path.Contains("jpg") || save_path.Contains("jpeg"))
                {
                    using (FileStream stream = new FileStream(save_path, FileMode.Create, FileAccess.ReadWrite))
                    {
                        BitmapEncoder encoder = new JpegBitmapEncoder();

                        encoder.Frames.Add(BitmapFrame.Create(wbitmap));
                        encoder.Save(stream);
                    }
                }
            }
            catch
            {
                System.Threading.Thread.Sleep(3);
            }
        }

        // =============================================================================================
        static void Main(string[] args)
        {
            // Azure Kinect Setting
            Device kinect_device = Device.Open(0);
            DeviceConfiguration device_config = new DeviceConfiguration();
            device_config.DepthMode = DepthMode.NFOV_Unbinned;
            device_config.ColorResolution = ColorResolution.R1536p;

            // Get Kinect Calibration
            Calibration calibration = kinect_device.GetCalibration(device_config.DepthMode, device_config.ColorResolution);

            // Calibration Setting
            Calibration re_calibration = SetCalibration(calibration);
            //Calibration org_device_calibration = kinect_device.GetCalibration(device_config.DepthMode, device_config.ColorResolution);

            // Create Transformation
            Transformation tr = new Transformation(re_calibration);

            /*   수집된 데이터 항목에서 Calibration Text File과 Depth Image File 호출하여 Transformation 진행 후 저장     */
            // Step 1. Calibration Text File Parsing
            // Step 2. Transform Depth to Color
            // Step 3. Save Image

            // Depth Image Path
            var depth_root_path = @"C:\AzureKinectData";
            var depth_fileName = "c0021_220615_kf_02_Depth_000000010.png"; // 16bit
            var depth_path = Path.Combine(depth_root_path, depth_fileName);

            // OpenCV Image
            Mat depth_img = GetCVImage(depth_path);
            Bitmap depth_cv2bitmap = BitmapConverter.ToBitmap(depth_img);
            int depth_width = depth_cv2bitmap.Width;
            int depth_height = depth_cv2bitmap.Height;
            int depth_stride = depth_cv2bitmap.Width * sizeof(UInt16);             Image depth_kinect_image_cv = new Image(Microsoft.Azure.Kinect.Sensor.ImageFormat.Depth16, depth_width, depth_height, depth_stride);

            // Bitmap Image
            Bitmap depth_org_bitmap = GetImage(depth_path);
            Image depth_kinect_image_bm = new Image(Microsoft.Azure.Kinect.Sensor.ImageFormat.Depth16, depth_width, depth_height, depth_stride);
            depth_kinect_image_bm = MakeImage(depth_org_bitmap, "depth");

            // Create Transformation Depth Image
            WriteableBitmap cv_wbitmap = DepthTransformer(tr, depth_kinect_image_cv);
            WriteableBitmap bm_wbitmap = DepthTransformer(tr, depth_kinect_image_bm);

            // Save Transformed Depth Image
            string serial_number = kinect_device.SerialNum.ToString();
            string save_path = @"C:\AzureKinectData\" + serial_number + "1536_test" + ".png";
            ImageSave(cv_wbitmap, save_path);
        }
    }
}
